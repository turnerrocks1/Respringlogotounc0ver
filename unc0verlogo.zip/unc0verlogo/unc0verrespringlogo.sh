rm /System/Library/PrivateFrameworks/BackBoardServices.framework/*.deb
cp -f -L *.png /System/Library/PrivateFrameworks/BackBoardServices.framework/
killall SpringBoard